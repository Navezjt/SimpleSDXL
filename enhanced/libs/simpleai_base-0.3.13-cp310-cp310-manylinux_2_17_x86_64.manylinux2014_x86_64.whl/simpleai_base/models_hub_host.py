models_hub_host = "http://124.222.60.66:1120"
models_hub_host_2 =  "http://91.229.91.74:1120"
accelerate_DID = "FWRfVFKLSrmmnrggmuCTATSqYpjGSPgu3"
    
